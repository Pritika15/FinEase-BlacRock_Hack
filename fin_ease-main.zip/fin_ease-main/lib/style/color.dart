import 'package:flutter/material.dart';

const primaryColor = Color(0xFF1F1F21);
const secondaryColor = Color(0xFF242627);
const buttonColor = Color(0xFFFDC448);
const textColor = Color(0xFFFFFFFF);
const text2Color = Color(0xFF000000);