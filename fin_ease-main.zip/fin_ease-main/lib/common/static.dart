import 'package:flutter/material.dart';

const imgBibit = 'lib/assets/images/bibit.jpg';
const imgGopay = 'lib/assets/images/gopay.jpg';
const imgProfile = 'lib/assets/images/profile.jpg';
const imgChip = 'lib/assets/images/chip.png';

const List widgetIcons = [Icons.money, Icons.book];
const List widgetTitles = [
  'Invest more',
  'Learn more',
];
