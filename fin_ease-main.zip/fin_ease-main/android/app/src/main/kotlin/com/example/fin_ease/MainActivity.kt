package com.example.fin_ease

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
